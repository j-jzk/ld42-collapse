class Config
	def initialize
		@input_method = :mouse
		@music_volume = 0.5
		@sfx_volume = 0.5
end