require 'rubygems'
require 'gosu'
require_relative './gameobject.rb'

class Settings < GameObject

end