HOW TO RUN THE GAME
===================

You will need a few dependencies to do it. 
The  whole process  of installing  them is 
explained at https://github.com/gosu/gosu/wiki
under   the   Installation   section.   To
actually  run the game,  open the terminal
(Command Line on Windows), navigate to the
game folder and type:

ruby collapse.rb
